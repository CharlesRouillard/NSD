to compile, just type make

Exo 1 : ./complexInfec <filename>
Exo 2 : ./reliability <filename>
Exo 3 : ./latency <filename> <id of a node>
Exo 4 : ./flooding <graph> -> generates trace data/flooding.txt